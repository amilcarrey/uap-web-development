/// <reference types="astro/client" />

declare namespace App {
    interface Locals {
      tasks: {
        text: string;
        done: boolean;
      }[];
    }
  }
  