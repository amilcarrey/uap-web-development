import type { APIRoute } from "astro";
import { tasks } from "../../../lib/tasks";

export const prerender = false;

export const POST: APIRoute = async ({ params, redirect }) => {
  const id = Number(params.id);
  if (!isNaN(id) && tasks[id]) {
    tasks[id].done = !tasks[id].done;
  }
  return redirect("/");
};
