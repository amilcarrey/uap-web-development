export type Task = {
    text: string;
    done: boolean;
  };
  
  export let tasks: Task[] = [];
  