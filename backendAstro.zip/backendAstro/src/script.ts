
document.addEventListener("DOMContentLoaded", () => {
  const formAgregar = document.getElementById(
    "form-agregar"
  ) as HTMLFormElement | null;
  const lista = document.getElementById(
    "lista-tareas"
  ) as HTMLUListElement | null;

  if (!formAgregar || !lista) {
    console.error("❌ No se encontraron los elementos necesarios en el DOM");
    return;
  }

  formAgregar?.addEventListener("submit", async (e) => {
    e.preventDefault();
    const input = document.getElementById(
      "input-tarea"
    ) as HTMLInputElement | null;
    if (!input) return;

    const texto = input.value.trim();
    if (!texto) return;

    const res = await fetch("/api/tareas", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ accion: "agregar", texto }),
    });

    const data = await res.json();
    input.value = "";
    renderTarea(data.tarea, lista);
  });

  function renderTarea(tarea: any, lista: HTMLUListElement) {
    const li = document.createElement("li");

    const completado = tarea.completada;
    const check = completado ? "✔️" : "";
    const btnClase = completado
      ? "bg-green-100 text-green-700 border-green-500"
      : "bg-white text-gray-800 border-gray-300 hover:bg-gray-100";
    const textoClase = completado
      ? "line-through text-gray-400"
      : "text-gray-800";

    li.innerHTML = `
          <div class="flex items-center justify-between gap-4 p-4 bg-white rounded shadow">
            <button data-toggle="${tarea.id}"
              class="text-xl w-7 h-7 flex items-center justify-center rounded-full border transition ${btnClase}">
              ${check}
            </button>
            <span class="flex-grow text-lg ${textoClase}">${tarea.texto}</span>
            <button data-borrar="${tarea.id}" class="text-white bg-red-500 hover:bg-red-700 px-3 py-1 rounded">🗑️</button>
          </div>
        `;
    lista.appendChild(li);
    bindBotones(li);
  }

  function bindBotones(scope: Document | HTMLElement = document) {
    scope.querySelectorAll("[data-toggle]").forEach((btn) => {
      btn.addEventListener("click", async (e) => {
        e.preventDefault?.();
        const id = (btn as HTMLElement).dataset.toggle;
        await fetch("/api/tareas", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ accion: "toggle", id: Number(id) }),
        });
        cargarTareas(lista!);
      });
    });

    scope.querySelectorAll("[data-borrar]").forEach((btn) => {
      btn.addEventListener("click", async (e) => {
        e.preventDefault?.();
        const id = (btn as HTMLElement).dataset.borrar;
        await fetch("/api/tareas", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ accion: "borrar", id: Number(id) }),
        });
        btn.closest("li")?.remove();
      });
    });
  }

  async function cargarTareas(lista: HTMLUListElement) {
    const res = await fetch("/api/tareas-data");
    const tareas = await res.json();
    lista.innerHTML = "";
    tareas.forEach((tarea: any) => {
      renderTarea(tarea, lista);
    });
  }

  cargarTareas(lista!);
});
