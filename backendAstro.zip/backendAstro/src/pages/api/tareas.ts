import type { APIRoute } from "astro";
import {
  agregarTarea,
  borrarTarea,
  toggleTarea,
  limpiarCompletadas,
} from "../lib/tareas";

export const POST: APIRoute = async ({ request }) => {
  const { accion, texto, id } = await request.json();

  if (accion === "agregar") {
    const tarea = agregarTarea(texto);
    return new Response(JSON.stringify({ tarea }), {
      headers: { "Content-Type": "application/json" },
    });
  }

  if (accion === "borrar") {
    borrarTarea(id);
    return new Response(JSON.stringify({ ok: true }));
  }

  if (accion === "toggle") {
    toggleTarea(id);
    return new Response(JSON.stringify({ ok: true }));
  }

  if (accion === "limpiar") {
    limpiarCompletadas();
    return new Response(JSON.stringify({ ok: true }));
  }

  return new Response(JSON.stringify({ ok: false }), {
    status: 400,
    headers: { "Content-Type": "application/json" },
  });
};
